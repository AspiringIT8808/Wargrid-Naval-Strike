"""Catalog screen: browse every ship and optional piece of equipment."""
import pygame

from ui.display import H, W, screen
from ui.screens.base import Screen
from ui.theme import ACCENT, ACCENT_DIM, BIG, FAINT, FONT, GOLD, MUTED, PANEL, PANEL_2, TEXT, vertical_gradient, panel
from ui.widgets import Button, text


CATALOG_ITEMS = {
    "Frigate (5x1)": {
        "group": "SHIP",
        "uses": "3 USES",
        "ability": "BARRAGE ATTACK",
        "description": [
            "The Frigate replaces its normal attack",
            "with a four-shot barrage."
        ],
    },
    "Destroyer (3x1)": {
        "group": "SHIP",
        "uses": "1 USE",
        "ability": "RELOCATE",
        "description": [
            "Move the Destroyer to a new untargeted",
            "location on your board. Its damage and",
            "shields travel with the ship.",
        ],
    },
    "Carrier (3x1)": {
        "group": "SHIP",
        "uses": "2 USES",
        "ability": "RECON",
        "description": [
            "Scan a 3x3 area of the enemy board and",
            "reveal ships within the area. Recon ends",
            "your turn after it is activated.",
        ],
    },
    "Cruiser (3x1)": {
        "group": "SHIP",
        "uses": "2 USES",
        "ability": "ROW SCAN",
        "description": [
            "Scan an entire enemy row and reveal any",
            "ships in that row. Row Scan ends your",
            "turn after it is activated.",
        ],
    },
    "Submarine (2x1)": {
        "group": "SHIP",
        "uses": "1 USE",
        "ability": "STEALTH",
        "description": [
            "Become untargetable for 3 enemy turns.",
            "Stealth also grants the Submarine one",
            "attack when activated.",
        ],
    },
    "Repair": {
        "group": "EQUIPMENT",
        "uses": "3 USES",
        "ability": "FIELD REPAIR",
        "description": [
            "Repair one hit part of a ship that is still",
            "afloat. The repaired segment can be",
            "targeted again. Repair ends your turn.",
        ],
    },
    "Shield": {
        "group": "EQUIPMENT",
        "uses": "3 USES",
        "ability": "SEGMENT SHIELD",
        "description": [
            "Protect one part of a ship for one hit.",
            "The shield is consumed when it blocks",
            "an incoming attack. Shield ends your turn.",
        ],
    },
    "Bomb": {
        "group": "EQUIPMENT",
        "uses": "TRAP",
        "ability": "HIDDEN CHARGE",
        "description": [
            "When hit by an opponent, the Bomb deals",
            "damage to one random surviving ship",
            "and is removed from the board.",
        ],
    },
}


class CatalogScreen(Screen):
    """A read-only reference screen for ships and optional equipment."""

    def __init__(self, app):
        super().__init__(app)
        self.ship_names = ["Frigate (5x1)", "Destroyer (3x1)", "Carrier (3x1)", "Cruiser (3x1)", "Submarine (2x1)"]
        self.equipment_names = ["Repair", "Shield", "Bomb"]
        self.ship_buttons = {
            name: Button((92, 158 + i * 72, 270, 60), name.upper())
            for i, name in enumerate(self.ship_names)
        }
        self.equipment_buttons = {
            name: Button((382, 158 + i * 72, 270, 60), name.upper())
            for i, name in enumerate(self.equipment_names)
        }
        self.back_btn = Button((W // 2 - 145, H - 72, 290, 52), "BACK TO COMMAND")
        self.selected = "Frigate (5x1)"

    def enter(self, **kwargs):
        self.selected = kwargs.get("selected", self.selected)

    def on_event(self, e):
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for name, button in {**self.ship_buttons, **self.equipment_buttons}.items():
                if button.hit(e.pos):
                    self.selected = name
                    button.punch()
                    return
            if self.back_btn.hit(e.pos):
                self.back_btn.punch()
                self.app.goto("menu")
        elif e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            self.app.goto("menu")

    def _draw_item_button(self, name, button):
        item = CATALOG_ITEMS[name]
        button.draw(selected=self.selected == name, label=name.upper(), sub=item["uses"])

    def _draw_detail(self):
        item = CATALOG_ITEMS[self.selected]
        detail = pygame.Rect(690, 132, 498, 516)
        panel(screen, detail, fill=PANEL, border=ACCENT_DIM, border_w=1, radius=12)
        text(item["group"], (detail.x + 30, detail.y + 28), pygame.font.SysFont("consolas", 13, bold=True), GOLD)
        text(self.selected.upper(), (detail.x + 30, detail.y + 58), BIG, ACCENT)
        text(item["ability"], (detail.x + 30, detail.y + 102), FONT, TEXT)
        pygame.draw.line(screen, FAINT, (detail.x + 30, detail.y + 140), (detail.right - 30, detail.y + 140), 1)
        text("FIELD NOTES", (detail.x + 30, detail.y + 166), pygame.font.SysFont("consolas", 13, bold=True), MUTED)
        for i, line in enumerate(item["description"]):
            text(line, (detail.x + 30, detail.y + 202 + i * 28), FONT, TEXT)
        tag = pygame.Rect(detail.x + 30, detail.bottom - 76, 180, 38)
        panel(screen, tag, fill=PANEL_2, border=ACCENT_DIM, border_w=1, radius=6, shadow=False)
        text(item["uses"], tag.center, pygame.font.SysFont("consolas", 14, bold=True), ACCENT, center=True)

    def draw(self):
        vertical_gradient(screen, (0, 0, W, H), (10, 16, 24), (6, 9, 14))
        text("WARGRID // CATALOG", (W // 2, 48), BIG, ACCENT, center=True)
        text("SHIP SYSTEMS + TACTICAL EQUIPMENT", (W // 2, 84), FONT, MUTED, center=True)

        text("SHIPS", (92, 122), pygame.font.SysFont("consolas", 13, bold=True), MUTED)
        text("EQUIPMENT", (382, 122), pygame.font.SysFont("consolas", 13, bold=True), MUTED)
        for name, button in self.ship_buttons.items():
            self._draw_item_button(name, button)
        for name, button in self.equipment_buttons.items():
            self._draw_item_button(name, button)
        self._draw_detail()
        self.back_btn.draw()
